package com.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring0626ApplicationTests {

	@Test
	void contextLoads() {
	}

}
